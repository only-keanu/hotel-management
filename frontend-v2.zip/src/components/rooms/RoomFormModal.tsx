import React, { useEffect, useState } from 'react';
import Modal from '../ui/Modal';
import { Room } from '../../utils/types';
interface RoomFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  room?: Room | null;
  onSave: (roomData: {
    id?: string;
    number: string;
    type: 'single' | 'double' | 'suite' | 'family';
    capacity: number;
    pricePerNight: number;
    status: 'available' | 'occupied' | 'maintenance';
    amenities: string[];
  }) => void;
}
const RoomFormModal: React.FC<RoomFormModalProps> = ({
  isOpen,
  onClose,
  room,
  onSave
}) => {
  const [number, setNumber] = useState('');
  const [type, setType] = useState<'single' | 'double' | 'suite' | 'family'>('single');
  const [capacity, setCapacity] = useState(1);
  const [pricePerNight, setPricePerNight] = useState(0);
  const [status, setStatus] = useState<'available' | 'occupied' | 'maintenance'>('available');
  const [amenities, setAmenities] = useState<string[]>([]);
  const [newAmenity, setNewAmenity] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const commonAmenities = ['Wi-Fi', 'TV', 'Air Conditioning', 'Mini Bar', 'Jacuzzi', 'Room Service', 'Kitchen', 'Ocean View', 'Balcony', 'Safe'];
  useEffect(() => {
    if (room) {
      setNumber(room.number);
      setType(room.type);
      setCapacity(room.capacity);
      setPricePerNight(room.pricePerNight);
      setStatus(room.status);
      setAmenities(room.amenities);
    } else {
      setNumber('');
      setType('single');
      setCapacity(1);
      setPricePerNight(0);
      setStatus('available');
      setAmenities([]);
    }
    setErrors({});
  }, [room, isOpen]);
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!number.trim()) newErrors.number = 'Room number is required';
    if (capacity < 1) newErrors.capacity = 'Capacity must be at least 1';
    if (pricePerNight <= 0) newErrors.pricePerNight = 'Price must be greater than 0';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    onSave({
      id: room?.id,
      number: number.trim(),
      type,
      capacity,
      pricePerNight,
      status,
      amenities
    });
    onClose();
  };
  const toggleAmenity = (amenity: string) => {
    if (amenities.includes(amenity)) {
      setAmenities(amenities.filter(a => a !== amenity));
    } else {
      setAmenities([...amenities, amenity]);
    }
  };
  const addCustomAmenity = () => {
    if (newAmenity.trim() && !amenities.includes(newAmenity.trim())) {
      setAmenities([...amenities, newAmenity.trim()]);
      setNewAmenity('');
    }
  };
  return <Modal isOpen={isOpen} onClose={onClose} title={room ? 'Edit Room' : 'Add New Room'} size="lg">
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Room Number*
              </label>
              <input type="text" value={number} onChange={e => setNumber(e.target.value)} className={`w-full p-2 border rounded-md ${errors.number ? 'border-red-500' : 'border-gray-300'}`} />
              {errors.number && <p className="text-red-500 text-xs mt-1">{errors.number}</p>}
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Room Type*
              </label>
              <select value={type} onChange={e => setType(e.target.value as any)} className="w-full p-2 border border-gray-300 rounded-md">
                <option value="single">Single</option>
                <option value="double">Double</option>
                <option value="suite">Suite</option>
                <option value="family">Family</option>
              </select>
            </div>
          </div>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Capacity*
              </label>
              <input type="number" value={capacity} min={1} onChange={e => setCapacity(parseInt(e.target.value))} className={`w-full p-2 border rounded-md ${errors.capacity ? 'border-red-500' : 'border-gray-300'}`} />
              {errors.capacity && <p className="text-red-500 text-xs mt-1">{errors.capacity}</p>}
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Price per Night*
              </label>
              <input type="number" value={pricePerNight} min={0} onChange={e => setPricePerNight(parseFloat(e.target.value))} className={`w-full p-2 border rounded-md ${errors.pricePerNight ? 'border-red-500' : 'border-gray-300'}`} />
              {errors.pricePerNight && <p className="text-red-500 text-xs mt-1">
                  {errors.pricePerNight}
                </p>}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status*
            </label>
            <select value={status} onChange={e => setStatus(e.target.value as any)} className="w-full p-2 border border-gray-300 rounded-md">
              <option value="available">Available</option>
              <option value="occupied">Occupied</option>
              <option value="maintenance">Maintenance</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Amenities
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-3">
              {commonAmenities.map(amenity => <button key={amenity} type="button" onClick={() => toggleAmenity(amenity)} className={`px-3 py-2 text-sm rounded-md border ${amenities.includes(amenity) ? 'bg-blue-100 border-blue-500 text-blue-800' : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100'}`}>
                  {amenity}
                </button>)}
            </div>
            <div className="flex gap-2">
              <input type="text" value={newAmenity} onChange={e => setNewAmenity(e.target.value)} placeholder="Add custom amenity" className="flex-1 p-2 border border-gray-300 rounded-md text-sm" />
              <button type="button" onClick={addCustomAmenity} className="px-4 py-2 text-sm bg-gray-600 text-white rounded-md hover:bg-gray-700">
                Add
              </button>
            </div>
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700">
              {room ? 'Update Room' : 'Add Room'}
            </button>
          </div>
        </div>
      </form>
    </Modal>;
};
export default RoomFormModal;